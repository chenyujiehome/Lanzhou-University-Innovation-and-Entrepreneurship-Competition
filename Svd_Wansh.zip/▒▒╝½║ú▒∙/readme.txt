运行顺序:
①ReadLeft.ncl
②LeftPlot.ncl
