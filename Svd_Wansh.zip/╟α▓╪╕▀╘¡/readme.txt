运行顺序:
①ReadRight.ncl
②RightPlot.ncl
